---
name: Bug report
about: Use this template for reporting a bug that you have found in ensmallen.
title: ''
labels: 't: bug report, s: unanswered'
assignees: ''

---

<!--

Welcome!  Please fill out the template below; that makes it easier for us to 
quickly figure out what the issue is and solve it.  Thanks!

-->

#### Issue description

<!-- Describe your issue here. -->

#### Your environment

 * version of ensmallen:
 * operating system:
 * compiler:
 * version of Armadillo:
 * any other environment information you think is relevant:

#### Steps to reproduce

<!-- Tell us how to reproduce the issue; please provide a working example if
possible! -->

#### Expected behavior

<!-- Tell us what should happen. -->

#### Actual behavior

<!-- Tell us what happened instead. -->
