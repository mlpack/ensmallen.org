/**
 * @file progress_bar.hpp
 * @author Marcus Edel
 *
 * Implementation of a simple progress bar callback function.
 *
 * ensmallen is free software; you may redistribute it and/or modify it under
 * the terms of the 3-clause BSD license.  You should have received a copy of
 * the 3-clause BSD license along with ensmallen.  If not, see
 * http://www.opensource.org/licenses/BSD-3-Clause for more information.
 */
#ifndef ENSMALLEN_CALLBACKS_PROGRESS_BAR_HPP
#define ENSMALLEN_CALLBACKS_PROGRESS_BAR_HPP

#include <ensmallen_bits/function.hpp>

namespace ens {

/**
 * A simple progress bar, based on the maximum number of optimizer iterations,
 * batch-size, number of functions and the StepTaken callback function.
 */
class ProgressBar
{
 public:
  /**
   * Set up the progress bar callback class with the given width and output
   * stream.
   *
   * @param widthIn Width of the bar.
   * @param ostream Ostream which receives output from this object.
   */
  ProgressBar(const size_t widthIn = 70,
              std::ostream& output = arma::get_cout_stream()) :
      width(widthIn),
      output(output),
      objective(0),
      epochs(0),
      epochSize(0),
      step(1),
      steps(0),
      newEpoch(false),
      epoch(1),
      epochStarted(false),
      epochCompleted(false)

  {
    if (widthIn == 0)
    {
      throw std::invalid_argument(
          "ProgressBar(): width must be greater than zero!");
    }
  }

  /**
   * Callback function called at the begin of the optimization process.
   *
   * @param optimizer The optimizer used to update the function.
   * @param function Function to optimize.
   * @param coordinates Starting point.
   */
  template<typename OptimizerType, typename FunctionType, typename MatType>
  void BeginOptimization(OptimizerType& optimizer,
                         FunctionType& function,
                         MatType& /* coordinates */)
  {
    static_assert(traits::HasBatchSizeSignature<
      OptimizerType>::value,
      "The OptimizerType does not have a correct definition of BatchSize(). "
      "Please check that the OptimizerType fully satisfies the requirements "
      "of the ProgressBar API; see the callbacks documentation for more "
      "details.");

    static_assert(traits::HasMaxIterationsSignature<
      OptimizerType>::value,
      "The OptimizerType does not have a correct definition of MaxIterations()."
      " Please check that the OptimizerType fully satisfies the requirements "
      "of the ProgressBar API; see the callbacks documentation for more "
      "details.");

    static_assert(traits::HasNumFunctionsSignature<
      FunctionType>::value,
      "The OptimizerType does not have a correct definition of NumFunctions(). "
      "Please check that the OptimizerType fully satisfies the requirements "
      "of the ProgressBar API; see the callbacks documentation for more "
      "details.");

    epochSize = function.NumFunctions() / optimizer.BatchSize();
    if (function.NumFunctions() % optimizer.BatchSize() > 0)
      epochSize++;

    epochs = optimizer.MaxIterations() / function.NumFunctions();
    if (optimizer.MaxIterations() % function.NumFunctions() > 0)
      epochs++;

    stepTimer.tic();
  }

  /**
   * Callback function called at the begin of a pass over the data.
   *
   * @param optimizer The optimizer used to update the function.
   * @param function Function to optimize.
   * @param coordinates Starting point.
   * @param epochIn The index of the current epoch.
   * @param objective Objective value of the current point.
   */
  template<typename OptimizerType, typename FunctionType, typename MatType>
  bool BeginEpoch(OptimizerType& /* optimizer */,
                  FunctionType& /* function */,
                  const MatType& /* coordinates */,
                  const size_t epochIn,
                  const double /* objective */)
  {
    // Start the timer.
    epochTimer.tic();

    // Reset epoch parameter.
    objective = 0;
    step = 1;

    epoch = epochIn;
    newEpoch = true;
    epochStarted = true;
    epochCompleted = false;

    return false;
  }

  /**
   * Callback function called once a step is taken.
   *
   * @param optimizer The optimizer used to update the function.
   * @param function Function to optimize.
   * @param coordinates Starting point.
   * @param objective Objective value of the current point.
   */
  template<typename OptimizerType, typename FunctionType, typename MatType>
  bool StepTaken(OptimizerType& /* optimizer */,
                 FunctionType& /* function */,
                 const MatType& /* coordinates */)
  {
    if (newEpoch)
    {
      output << "Epoch " << epoch;
      if (epochs > 0)
      {
        output << "/" << epochs;
      }
      output << '\n';
      newEpoch = false;
    }

    const double progress = ((double) step / epochSize);
    output << step++ << "/" << epochSize << " [";
    for (size_t i = 0; i < width; ++i)
    {
      // Compute the "beginning percentage" and "end percentage" of this
      // character.
      const double charBeginPct = double(i) / double(width);
      const double charEndPct = double(i + 1) / double(width);
      if (progress >= charEndPct)
      {
        output << "=";
      }
      else if (progress >= charBeginPct && progress < charEndPct)
      {
        output << ">";
      }
      else
      {
        output << ".";
      }
    }

    size_t progressPrintPct = size_t(progress * 100);
    output << "] ";
    if (progressPrintPct < 100)
      output << " "; // leading space for lower than 100%
    output << progressPrintPct << "% - ETA: "
        << (size_t) (stepTimer.toc() * (epochSize - step + 1)) % 60
        << "s - loss: " << (objective / (double) step) <<  "\r";
    output.flush();

    stepTimer.tic();

    return false;
  }

  /**
   * Callback function called at any call to Evaluate().
   *
   * @param optimizer The optimizer used to update the function.
   * @param function Function to optimize.
   * @param coordinates Starting point.
   * @param objectiveIn Objective value of the current point.
   */
  template<typename OptimizerType, typename FunctionType, typename MatType>
  bool Evaluate(OptimizerType& optimizer,
                FunctionType& /* function */,
                const MatType& /* coordinates */,
                const double objectiveIn)
  {
    objective += objectiveIn / optimizer.BatchSize();
    steps++;
    return false;
  }

  /**
   * Callback function called at the end of a pass over the data.
   *
   * @param optimizer The optimizer used to update the function.
   * @param function Function to optimize.
   * @param coordinates Starting point.
   * @param epoch The index of the current epoch.
   * @param objective Objective value of the current point.
   */
  template<typename OptimizerType, typename FunctionType, typename MatType>
  bool EndEpoch(OptimizerType& /* optimizer */,
                FunctionType& /* function */,
                const MatType& /* coordinates */,
                const size_t /* epoch */,
                const double objective)
  {
    epochCompleted = true;

    // Print the entire row of '='s.
    output << step - 1 << "/" << epochSize << " [" << std::string(width, '=');

    const double epochTimerElapsed = epochTimer.toc();
    const size_t stepTime = epochTimerElapsed / (double) epochSize * 1000;
    output << "] 100% - " << epochTimerElapsed << "s/epoch; " << stepTime
        << "ms/step; loss: " << objective  <<  "\n";
    output.flush();
    return false;
  }

  /**
   * Callback function called at the end of the optimization process.
   *
   * @param optimizer The optimizer used to update the function.
   * @param function Function to optimize.
   * @param coordinates Final point.
   */
  template<typename OptimizerType, typename FunctionType, typename MatType>
  void EndOptimization(OptimizerType& /* optimizer */,
                       FunctionType& /* function */,
                       MatType& /* coordinates */)
  {
    if (epochStarted && !epochCompleted && step > 1)
    {
      output << "\nOptimization stopped before completing the current epoch."
          << std::endl;
    }
  }

 private:
  // Number of characters used to print the progress bar.
  size_t width;

  // The output stream that all data is to be sent to; example: std::cout.
  std::ostream& output;

  // Objective over the current epoch.
  double objective;

  // Total number of epochs
  size_t epochs;

  // Number of steps per epoch.
  size_t epochSize;

  // Current step number.
  size_t step;

  // Number of steps taken.
  size_t steps;

  // Indicates a new epoch.
  bool newEpoch;

  // Locally-stored epoch.
  size_t epoch;

  // Tracks whether there is an epoch whose progress is being displayed.
  bool epochStarted;

  // Lets EndOptimization() distinguish a complete epoch from a partial one.
  bool epochCompleted;

  // Locally-stored step timer object.
  arma::wall_clock stepTimer;

  // Locally-stored epoch timer object.
  arma::wall_clock epochTimer;
};

} // namespace ens

#endif
