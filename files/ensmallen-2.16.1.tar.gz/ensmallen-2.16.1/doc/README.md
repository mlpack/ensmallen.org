The documentation in this directory is what is used to generate the page

  http://www.ensmallen.org/docs.html

You can read it here directly also.

If you are implementing a new optimizer, be sure to add documentation to
optimizers.md and links in function_types.md!
